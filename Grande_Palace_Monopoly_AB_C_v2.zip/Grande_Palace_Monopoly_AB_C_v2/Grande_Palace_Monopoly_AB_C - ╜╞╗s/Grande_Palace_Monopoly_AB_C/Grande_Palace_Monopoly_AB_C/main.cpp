#include "Game/Game.hpp"
#include "Game/GameConfig.hpp"
#include "Game/SingletonManager.hpp"
#include "Game/Player.hpp"
#include "Game/BotPlayer.hpp"
#include "Cards/RocketCard.hpp"
#include <exception>
#include <iostream>
#include <algorithm>
#include <random>

using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    srand(time(nullptr)); // Seed random generator for dice

    // Load game configuration from file
    GameConfig& config = GameConfig::getInstance();
    try {
        config.loadConfig();
    }
    catch (const std::exception& e) {
        cerr << "Config load error: " << e.what() << endl;
        return 1;
    }

    // Ask for number of players (2-4)
    int numPlayers;
    cout << "�п�J���a�H�� (2-4): ";
    cin >> numPlayers;
    while (numPlayers < 2 || numPlayers > 4) {
        cout << "���a�ƶq�u��O 2 �� 4 �H�A�Э��s��J: ";
        cin >> numPlayers;
    }
    config.setPlayersNum(numPlayers);

    // Ask if including Bot players and get names
    vector<shared_ptr<Player>> players;
    for (int i = 1; i <= numPlayers; ++i) {
        char botChoice;
        cout << "���a" << i << " �O�_���q�����a (y/n)? ";
        cin >> botChoice;
        bool isBot = (botChoice == 'y' || botChoice == 'Y');
        string name;
        if (isBot) {
            name = "Bot" + to_string(i);
        }
        else {
            cout << "�п�J���a" << i << "���W��: ";
            cin >> name;
        }
        // Ensure name is unique
        for (const auto& p : players) {
            if (p->getName() == name) {
                name += "_";
                break;
            }
        }
        // Assign icon and color from config lists
        string icon = config.getPlayerIcons()[i - 1];
        string color = config.getPlayerColors()[i - 1];
        long long startMoney = 0;
        // Use default from config based on mode (if 2 players use DUEL, else DEBUG)
        if (numPlayers == 2) {
            config.setMode(GameMode::DUEL);
            startMoney = config.getStartMoney();
        }
        else {
            config.setMode(GameMode::DEBUG);
            startMoney = config.getStartMoney();
        }
        shared_ptr<Player> player;
        if (isBot) {
            player = make_shared<BotPlayer>(name, icon, color, startMoney);
        }
        else {
            player = make_shared<Player>(name, icon, color, startMoney);
        }
        players.push_back(player);
    }

    // Ask for map type selection
    int mapChoice;
    cout << "�п�ܦa������ (1.�g��a�� 2.���Ŧa�� 3.�H��): ";
    cin >> mapChoice;
    // If random selected, shuffle board tiles order (keep Start at index 0)
    if (mapChoice == 3) {
        vector<TileConfig> tiles = config.getBoardTiles();
        // find start tile and remove from list
        TileConfig startTile;
        bool startFound = false;
        vector<TileConfig> others;
        for (auto& t : tiles) {
            if (!startFound && t.id == 0 && (t.type == "start" || t.type == "START")) {
                startTile = t;
                startFound = true;
            }
            else {
                others.push_back(t);
            }
        }
        // shuffle others
        std::shuffle(others.begin(), others.end(), std::default_random_engine(std::random_device{}()));
        // combine with start at front
        vector<TileConfig> shuffled;
        if (startFound) {
            shuffled.push_back(startTile);
        }
        shuffled.insert(shuffled.end(), others.begin(), others.end());
        config.setBoardTiles(shuffled);
    }

    // Ask for victory condition
    cout << "�п�ܳӧQ���� (1.�겣�F�� 2.�a���L�b 3.�^�X��): ";
    int victoryChoice;
    cin >> victoryChoice;
    int maxRounds = 0;
    if (victoryChoice == 3) {
        cout << "�п�J�̦h�i�檺�^�X��: ";
        cin >> maxRounds;
        if (maxRounds < 1) maxRounds = 10;
    }

    // Initialize game singleton and board
    shared_ptr<Game> game = Game::getInstance(config);
    game->addPlayers(players);
    game->initGame();
    // Start game loop
    game->start(victoryChoice, maxRounds);

    // End of game
    Board::destroyInstance();
    return 0;
}