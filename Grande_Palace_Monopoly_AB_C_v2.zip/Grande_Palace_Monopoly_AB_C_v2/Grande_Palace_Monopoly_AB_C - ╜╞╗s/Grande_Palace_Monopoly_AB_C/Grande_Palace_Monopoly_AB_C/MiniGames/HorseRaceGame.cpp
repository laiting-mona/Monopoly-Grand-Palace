/**
 * @file HorseRaceGame.cpp
 * @brief �䰨�p�C������@
 * @details ��@�䰨�C�����C���޿�A�]�A��`�B�H�����ɵ��G�P�����p��
 */
#include "HorseRaceGame.hpp"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <limits>
using namespace std;

int HorseRaceGame::play() {
    cout << "========== Horse Race Game ==========" << endl;
    // Prompt for bet amount
    int bet = 0;
    do {
        cout << "Enter your bet amount: ";
        if (!(cin >> bet)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            bet = 0;
        }
        if (bet <= 0) {
            cout << "Bet must be a positive integer." << endl;
        }
    } while (bet <= 0);

    // Prompt for horse choice
    int horseCount = 3;  // number of horses in the race
    int choice = 0;
    do {
        cout << "Choose a horse to bet on (1-" << horseCount << "): ";
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            choice = 0;
        }
        if (choice < 1 || choice > horseCount) {
            cout << "Invalid choice. Please select a horse between 1 and " << horseCount << "." << endl;
        }
    } while (choice < 1 || choice > horseCount);

    // Initialize net result and subtract bet from player's money
    int netResult = 0;
    netResult -= bet;

    cout << "The race is about to start... and they're off!" << endl;

    // Simulate a simple race commentary
    int winner = 1 + rand() % horseCount;
    int lead1 = 1 + rand() % horseCount;
    if (lead1 == winner) {
        // ensure initial lead is not the same as eventual winner
        lead1 = (lead1 % horseCount) + 1;
    }
    cout << "Horse " << lead1 << " takes an early lead!" << endl;
    cout << "Around the final turn, horse " << winner << " is making a move!" << endl;

    // Announce winner
    cout << "And the winner is... Horse " << winner << "!" << endl;

    // Determine outcome
    if (choice == winner) {
        cout << "Congratulations! Your horse won the race!" << endl;
        // Winner gets double the bet (profit equal to bet)
        netResult += bet * 2;
    }
    else {
        cout << "Your horse didn't win. Better luck next time!" << endl;
        // netResult remains -bet (lost bet)
    }

    cout << "======================================" << endl;
    return netResult;
}