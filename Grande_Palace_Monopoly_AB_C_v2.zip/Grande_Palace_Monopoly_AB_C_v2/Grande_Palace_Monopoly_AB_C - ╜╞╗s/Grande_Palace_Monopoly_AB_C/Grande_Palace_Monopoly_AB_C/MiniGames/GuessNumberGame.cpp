/**
 * @file GuessNumberGame.cpp
 * @brief �q�Ʀr�p�C������@
 * @details ��@�q�Ʀr�C���޿�A�]�A�U�`�B�H���ͦ��ؼмƦr�B���Ѵ��ܻP�ӭt�P�w
 */
#include "GuessNumberGame.hpp"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <limits>

using namespace std;

int GuessNumberGame::play() {
    cout << "========== Guess Number Game ==========" << endl;
    // �U�`���B��J
    int bet = 0;
    do {
        cout << "Enter your bet amount: ";
        if (!(cin >> bet)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            bet = 0;
        }
        if (bet <= 0) {
            cout << "Bet must be a positive integer." << endl;
        }
    } while (bet <= 0);

    // �����U�`�]���O���t�ȡ^
    int netResult = -bet;

    // ��l���H���ƺؤl & �ؼмƦr�]1�V100�^
    srand(static_cast<unsigned>(time(nullptr)));
    int target = 1 + rand() % 100;

    cout << "I have selected a number between 1 and 100." << endl;
    cout << "You have 7 attempts to guess it. Good luck!" << endl;

    // �̦h 7 ������
    const int maxAttempts = 7;
    for (int attempt = 1; attempt <= maxAttempts; ++attempt) {
        int guess = 0;
        cout << "[" << attempt << "/" << maxAttempts << "] Your guess: ";
        if (!(cin >> guess)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter an integer." << endl;
            --attempt;  // ���p�J���զ���
            continue;
        }

        if (guess == target) {
            // �q���GĹ�o�⭿�U�`�]�b�Q����U�`�B�^
            cout << "Congratulations! You guessed it right." << endl;
            cout << "You win $" << bet * 2 << "!" << endl;
            netResult += bet * 2;
            break;
        }
        else if (guess < target) {
            cout << "Too low." << endl;
        }
        else {
            cout << "Too high." << endl;
        }

        if (attempt == maxAttempts) {
            cout << "Out of attempts! The correct number was " << target << "." << endl;
        }
    }

    cout << "======================================" << endl;
    return netResult;
}