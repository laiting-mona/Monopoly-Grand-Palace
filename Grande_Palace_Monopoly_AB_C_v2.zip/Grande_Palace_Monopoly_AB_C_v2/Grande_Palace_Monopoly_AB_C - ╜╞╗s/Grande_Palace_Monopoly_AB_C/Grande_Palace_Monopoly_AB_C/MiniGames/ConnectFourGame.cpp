/**
 * @file ConnectFourGame.cpp
 * @brief Connect Four�]�|�l�s�]�^�p�C����@
 * @details �]�t�U�`�B�ѽL�޲z�B�X�k�ۤl�B�ӭt�P�w�A�H�� AI �ĥ� Minimax+�\�V�]
 */
#include "ConnectFourGame.hpp"
#include <iostream>
#include <vector>
#include <limits>
#include <algorithm>
#include <ctime>
#include <cstdlib>

using namespace std;

static const int ROWS = 6;
static const int COLS = 7;
static const int WIN_COUNT = 4;
static const int MAX_DEPTH = 5;

// �ѽL�G0 �šA1 ���a�A2 AI
using Board = vector<vector<int>>;

// �ˬd�O�_�s���|�l
bool checkWin(const Board& b, int pid) {
    // �����B�����B�׽u�|�V���y
    for (int r = 0; r < ROWS; ++r)
        for (int c = 0; c < COLS; ++c) if (b[r][c] == pid) {
            // �|�Ӥ�V���W�q
            const int dr[4] = { 0,1,1,1 }, dc[4] = { 1,0,1,-1 };
            for (int d = 0; d < 4; ++d) {
                int cnt = 0;
                for (int k = 0; k < WIN_COUNT; ++k) {
                    int nr = r + dr[d] * k, nc = c + dc[d] * k;
                    if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS || b[nr][nc] != pid) break;
                    ++cnt;
                }
                if (cnt == WIN_COUNT) return true;
            }
        }
    return false;
}

// �����禡�G²�������]���ߦC�[�� + ��T�s���ơ^
int evaluate(const Board& b) {
    int score = 0;
    // ���ߦC�u��
    for (int r = 0; r < ROWS; ++r) {
        if (b[r][COLS / 2] == 2) score += 3;
        else if (b[r][COLS / 2] == 1) score -= 3;
    }
    // TODO: �i�X�R�s�u�Ҧ�����
    return score;
}

// ���o�X�k�Ҧ��C
vector<int> validCols(const Board& b) {
    vector<int> cols;
    for (int c = 0; c < COLS; ++c) {
        if (b[0][c] == 0) cols.push_back(c);
    }
    return cols;
}

// �b col �ۤl�A��^�s�ѽL
Board dropPiece(Board b, int col, int pid) {
    for (int r = ROWS - 1; r >= 0; --r) {
        if (b[r][col] == 0) {
            b[r][col] = pid;
            break;
        }
    }
    return b;
}

// Minimax�ϣ\�V�] �ŪK
int minimax(Board b, int depth, int alpha, int beta, bool maximizing) {
    if (checkWin(b, 2))  return numeric_limits<int>::max() / 2;
    if (checkWin(b, 1))  return numeric_limits<int>::min() / 2;
    if (depth == 0 || validCols(b).empty()) return evaluate(b);
    if (maximizing) {
        int value = numeric_limits<int>::min();
        for (int col : validCols(b)) {
            Board nb = dropPiece(b, col, 2);
            value = max(value, minimax(nb, depth - 1, alpha, beta, false));
            alpha = max(alpha, value);
            if (alpha >= beta) break;
        }
        return value;
    }
    else {
        int value = numeric_limits<int>::max();
        for (int col : validCols(b)) {
            Board nb = dropPiece(b, col, 1);
            value = min(value, minimax(nb, depth - 1, alpha, beta, true));
            beta = min(beta, value);
            if (alpha >= beta) break;
        }
        return value;
    }
}

// AI ��̨ܳΦC
int pickBestMove(Board b) {
    int bestScore = numeric_limits<int>::min();
    int bestCol = validCols(b)[0];
    for (int col : validCols(b)) {
        Board nb = dropPiece(b, col, 2);
        int sc = minimax(nb, MAX_DEPTH - 1,
            numeric_limits<int>::min(),
            numeric_limits<int>::max(),
            false);
        if (sc > bestScore) {
            bestScore = sc;
            bestCol = col;
        }
    }
    return bestCol;
}

int ConnectFourGame::play() {
    cout << "======= Connect Four Game =======" << endl;
    // 1. �U�`
    int bet = 0;
    do {
        cout << "Enter your bet amount: ";
        if (!(cin >> bet)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            bet = 0;
        }
        if (bet <= 0) cout << "Bet must be positive.\n";
    } while (bet <= 0);
    int net = -bet;

    // 2. ��l�ƴѽL
    Board board(ROWS, vector<int>(COLS, 0));
    bool playerTurn = true;

    // 3. �C���^�X
    while (true) {
        // ��ܴѽL
        cout << "\n  ";
        for (int c = 0; c < COLS; ++c) cout << c << ' ';
        cout << "\n";
        for (int r = 0; r < ROWS; ++r) {
            cout << r << ' ';
            for (int c = 0; c < COLS; ++c) {
                char ch = (board[r][c] == 1 ? 'O' : board[r][c] == 2 ? 'X' : '�P');
                cout << ch << ' ';
            }
            cout << "\n";
        }
        // ���a�� AI �U�l
        int col;
        if (playerTurn) {
            cout << "Your move (0�V" << COLS - 1 << "): ";
            cin >> col;
            if (find(validCols(board).begin(), validCols(board).end(), col)
                == validCols(board).end()) {
                cout << "Invalid column.\n";
                continue;
            }
            board = dropPiece(board, col, 1);
            if (checkWin(board, 1)) {
                cout << "You connected four! You win.\n";
                net += bet * 2;
                break;
            }
        }
        else {
            cout << "AI is thinking...\n";
            int aiCol = pickBestMove(board);
            board = dropPiece(board, aiCol, 2);
            cout << "AI drops at " << aiCol << ".\n";
            if (checkWin(board, 2)) {
                cout << "AI connected four! You lose.\n";
                break;
            }
        }
        // �����P�w
        if (validCols(board).empty()) {
            cout << "Board full! It's a draw.\n";
            // draw: �h�^��`
            net += bet;
            break;
        }
        playerTurn = !playerTurn;
    }

    cout << "==================================" << endl;
    return net;
}