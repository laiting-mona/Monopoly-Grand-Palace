/**
 * @file MinesweeperGame.cpp
 * @brief Minesweeper�]��a�p�^�p�C����@
 * @details �]�t�a�p�G�m�B�F���p��B���j�ݮi½���޿�P�U�`����
 * 
 * @ descriptions
 * �U�`����G�C���}�l�Y�n�D���a��J��` bet�A������`�᪺ netResult = -bet�C
 * �ӧQ����G���Ʀw����Q½�} (cellsToReveal == 0) �P���ӧQ�A�����⭿��`�^���A�b�o +bet�C
 * ���ѱ���G�򤤦a�p�Y���ѡA�b�l -bet�C
 * �^�ǭȡGplay() �̫�^�� netResult�A��K MiniGameManager �ե�
 */
#include "MinesweeperGame.hpp"
#include <iostream>
#include <vector>
#include <queue>
#include <random>
#include <ctime>
#include <limits>
#include <iomanip>

using namespace std;

static const int SIZE = 9;
static const int MINES = 10;
const int dx[8] = { -1,-1,-1, 0, 0, 1, 1, 1 };
const int dy[8] = { -1, 0, 1,-1, 1,-1, 0, 1 };

int MinesweeperGame::play() {
    cout << "====== Minesweeper Game ======" << endl;

    // 1. �U�`���B
    int bet = 0;
    do {
        cout << "Enter your bet amount: ";
        if (!(cin >> bet)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            bet = 0;
        }
        if (bet <= 0) {
            cout << "Bet must be a positive integer." << endl;
        }
    } while (bet <= 0);

    int netResult = -bet;

    // 2. �إߦa�ϻP��ܪO
    vector<vector<int>> board(SIZE, vector<int>(SIZE, 0));
    vector<vector<bool>> revealed(SIZE, vector<bool>(SIZE, false));
    vector<vector<bool>> flagged(SIZE, vector<bool>(SIZE, false));

    // 3. �H���G�m�a�p�íp��F���
    mt19937 rng(static_cast<unsigned>(time(nullptr)));
    uniform_int_distribution<int> dist(0, SIZE * SIZE - 1);
    int placed = 0;
    while (placed < MINES) {
        int idx = dist(rng);
        int x = idx / SIZE, y = idx % SIZE;
        if (board[x][y] != -1) {
            board[x][y] = -1;
            placed++;
            for (int d = 0; d < 8; ++d) {
                int nx = x + dx[d], ny = y + dy[d];
                if (nx >= 0 && nx < SIZE && ny >= 0 && ny < SIZE && board[nx][ny] != -1) {
                    board[nx][ny]++;
                }
            }
        }
    }

    // ��ܭ��O�禡
    auto printBoard = [&]() {
        cout << "   ";
        for (int j = 0; j < SIZE; ++j) cout << setw(2) << j;
        cout << "\n  +" << string(SIZE * 2, '-') << "+\n";
        for (int i = 0; i < SIZE; ++i) {
            cout << setw(2) << i << "|";
            for (int j = 0; j < SIZE; ++j) {
                if (flagged[i][j])         cout << " F";
                else if (!revealed[i][j])   cout << " #";
                else if (board[i][j] == -1) cout << " *";
                else                         cout << setw(2) << board[i][j];
            }
            cout << " |\n";
        }
        cout << "  +" << string(SIZE * 2, '-') << "+\n";
    };

    // 4. �C���j��
    int cellsToReveal = SIZE * SIZE - MINES;
    bool won = false;
    while (true) {
        printBoard();
        cout << "Enter command (o x y = open, f x y = flag): ";
        char cmd; int x, y;
        cin >> cmd >> x >> y;
        if (!cin || x < 0 || x >= SIZE || y < 0 || y >= SIZE) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Try again.\n";
            continue;
        }
        if (cmd == 'f' || cmd == 'F') {
            flagged[x][y] = !flagged[x][y];
            continue;
        }
        if (cmd != 'o' && cmd != 'O') {
            cout << "Unknown command.\n";
            continue;
        }
        if (flagged[x][y] || revealed[x][y]) {
            cout << "Cell already flagged or revealed.\n";
            continue;
        }

        // 5. �}���޿�
        if (board[x][y] == -1) {
            revealed[x][y] = true;
            cout << "\nBOOM! You hit a mine at (" << x << "," << y << ").\n";
            break;
        }
        // BFS �i�}
        queue<pair<int, int>> q;
        q.push({ x,y });
        revealed[x][y] = true;
        cellsToReveal--;
        while (!q.empty()) {
            auto [cx, cy] = q.front(); q.pop();
            if (board[cx][cy] != 0) continue;
            for (int d = 0; d < 8; ++d) {
                int nx = cx + dx[d], ny = cy + dy[d];
                if (nx >= 0 && nx < SIZE && ny >= 0 && ny < SIZE && !revealed[nx][ny] && !flagged[nx][ny]) {
                    revealed[nx][ny] = true;
                    cellsToReveal--;
                    if (board[nx][ny] == 0) q.push({ nx,ny });
                }
            }
        }
        if (cellsToReveal == 0) {
            won = true;
            cout << "\nCongratulations! You cleared all safe cells.\n";
            break;
        }
    }

    // 6. ��̲ܳת���
    for (int i = 0; i < SIZE; ++i)
        for (int j = 0; j < SIZE; ++j)
            revealed[i][j] = true;
    printBoard();

    // 7. ����
    if (won) {
        cout << "You win! Payout: " << bet * 2 << endl;
        netResult += bet * 2;
    }
    else {
        cout << "Game over. You lose your bet of " << bet << "." << endl;
    }

    cout << "===============================" << endl;
    return netResult;
}