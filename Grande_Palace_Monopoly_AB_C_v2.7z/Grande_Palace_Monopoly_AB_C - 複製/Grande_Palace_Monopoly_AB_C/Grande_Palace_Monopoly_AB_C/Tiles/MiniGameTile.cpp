#include "MiniGameTile.hpp"
#include "Game/MiniGameManager.hpp"
#include "Game/Player.hpp"

TileAction MiniGameTile::landOn(std::shared_ptr<Player> player) {
    if (miniGameManager && player) {
        miniGameManager->playMiniGame(player);
    }
    return TileAction::MINI_GAME;
}
