/**
 * @file DemolitionCard.cpp
 * @brief DemolitionCard ���O����@�ɮסC
 */

#include "DemolitionCard.hpp"
#include "Game/Player.hpp"
#include "Tiles/PropertyTile.hpp"
#include <iostream>

using namespace std;

DemolitionCard::DemolitionCard()
    : Card("Demolition", "XXXX", 200, "Lower the level of a property by 1")
    , targetProperty(nullptr) {
}

void DemolitionCard::useEffect(vector<shared_ptr<Player>>& players, shared_ptr<Player> curPlayer) {
    // Ensure a target property has been set
    if (!targetProperty) {
        cout << "No target property selected for demolition!" << endl;
        return;
    }
    // Get current level of the property
    PropertyLevel currentLevel = targetProperty->getPropertyLevel();
    if (currentLevel == PropertyLevel::VACANT) {
        cout << "Property is already vacant and cannot be demolished further." << endl;
        return;
    }
    // Determine the new level (one level lower)
    PropertyLevel newLevel;
    switch (currentLevel) {
    case PropertyLevel::LEVEL_1:
        newLevel = PropertyLevel::VACANT;
        break;
    case PropertyLevel::LEVEL_2:
        newLevel = PropertyLevel::LEVEL_1;
        break;
    case PropertyLevel::LEVEL_3:
        newLevel = PropertyLevel::LEVEL_2;
        break;
    case PropertyLevel::MAX_LEVEL:
        newLevel = PropertyLevel::LEVEL_3;
        break;
    default:
        newLevel = PropertyLevel::VACANT;
    }
    // Set the property's new level
    targetProperty->setPropertyLevel(newLevel);
    // If property becomes vacant, remove ownership
    if (newLevel == PropertyLevel::VACANT) {
        shared_ptr<Player> owner = targetProperty->getPropertyOwner();
        if (owner) {
            owner->removeProperty(targetProperty);
            targetProperty->setPropertyOwner(nullptr);
        }
    }
    // Output the demolition result
    string message = curPlayer->getDisplayName() + " used Demolition card on " + targetProperty->getName() +
        ". Level reduced to " + to_string(static_cast<int>(newLevel)) + "!";
    cout << message << endl;
    // The card is consumed after use (handled by the game engine)
}

void DemolitionCard::setTargetProperty(shared_ptr<PropertyTile> property) {
    targetProperty = property;
}

shared_ptr<PropertyTile> DemolitionCard::getTargetProperty() const {
    return targetProperty;
}