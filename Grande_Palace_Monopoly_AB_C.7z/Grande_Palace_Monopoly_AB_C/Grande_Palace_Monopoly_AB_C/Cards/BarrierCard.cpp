/**
 * @file BarrierCard.cpp
 * @brief BarrierCard ���O����@�ɮסC
 */

#include "BarrierCard.hpp"
#include "Game/Player.hpp"
#include "Game/Board.hpp"
#include "Tiles/Tile.hpp"
#include <iostream>

using namespace std;

BarrierCard::BarrierCard()
    : Card("Barrier", "====", 100, "Place a barrier to block the next player who passes by")
    , tilePosition(-1)
    , targetTile(nullptr) {
}

BarrierCard::~BarrierCard() {
}

void BarrierCard::useEffect(vector<shared_ptr<Player>>& players, shared_ptr<Player> curPlayer) {
    // If no target tile is set
    if (!targetTile && tilePosition < 0) {
        cout << "No target tile selected for the barrier!" << endl;
        return;
    }
    // If tile is specified by position but not set as object, attempt to retrieve from board
    if (!targetTile && tilePosition >= 0) {
        Board* board = Board::getInstance();
        if (board) {
            try {
                targetTile = board->getTile(tilePosition);
            }
            catch (const out_of_range&) {
                // If tile not found, we handle it below
            }
        }
        /*
        // In a real implementation, obtain the tile from the game board using the position.
        // Here, if the tile cannot be found, we simply do nothing.
        // cout << "Unable to locate the tile at position " << tilePosition << endl;
        // return;
        */
    }
    // Place the barrier if a valid target tile is available
    if (targetTile) {
        targetTile->setBlock(true);
        string message = curPlayer->getDisplayName() + " placed a Barrier on tile " + targetTile->getName() + "!";
        cout << message << endl;
    }
    // The card is consumed after use (handled by the game engine)
}

void BarrierCard::setTargetTile(shared_ptr<Tile> tile) {
    targetTile = tile;
    if (tile) {
        // Update the position index based on the provided tile
        tilePosition = static_cast<int>(tile->getId());
    }
}

shared_ptr<Tile> BarrierCard::getTargetTile() const {
    return targetTile;
}

void BarrierCard::setTilePosition(int position) {
    tilePosition = position;
    // Note: In a real implementation, you would update targetTile using the Board.
}

int BarrierCard::getTilePosition() const {
    return tilePosition;
}