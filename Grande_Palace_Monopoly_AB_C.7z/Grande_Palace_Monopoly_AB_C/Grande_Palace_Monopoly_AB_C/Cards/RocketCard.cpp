/**
 * @file RocketCard.cpp
 * @brief RocketCard ���O����@�ɮסC
 */

#include "RocketCard.hpp"
#include "Game/Player.hpp"
#include <iostream>

using namespace std;

RocketCard::RocketCard(int turns)
    : Card("Rocket", ">>>>", 250, "Send a player to hospital for a few turns")
    , hospitalTurns(turns)
    , targetPlayer(nullptr) {
}

void RocketCard::useEffect(vector<shared_ptr<Player>>& players, shared_ptr<Player> curPlayer) {
    // Ensure a target player has been set
    if (!targetPlayer) {
        cout << "No target player selected for the rocket!" << endl;
        return;
    }
    // Send the target player to the hospital for the specified number of turns
    targetPlayer->sendToHospital(hospitalTurns);
    string message = curPlayer->getDisplayName() + " used Rocket card on " +
        targetPlayer->getDisplayName() + ", sending them to hospital for " +
        to_string(hospitalTurns) + " turns!";
    cout << message << endl;
}

void RocketCard::setTargetPlayer(shared_ptr<Player> player) {
    targetPlayer = player;
}

shared_ptr<Player> RocketCard::getTargetPlayer() const {
    return targetPlayer;
}

void RocketCard::setHospitalTurns(int turns) {
    hospitalTurns = turns;
}

int RocketCard::getHospitalTurns() const {
    return hospitalTurns;
}