#include "Game.hpp"
#include "Error.hpp"
#include "InputManager.hpp"
#include "Utils.hpp"
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <random>
#include <unordered_map>
#include <limits>

std::default_random_engine Game::engine;
std::shared_ptr<Game> Game::instance = nullptr;

Game::Game(const GameConfig& cfg)
    : board(nullptr)
    , config(cfg)
    , currentState(State::INIT)
    , gameForceControl(false) {
}

std::shared_ptr<Game> Game::getInstance(const GameConfig& config) {
    if (!instance) {
        instance = std::shared_ptr<Game>(new Game(config));
    }
    return instance;
}

void Game::initGame() {
    // Initialize game board with configuration and players
    board = Board::getInstance(config);
    if (board) {
        board->init(config, players);
    }
}

void Game::start(int victoryCondition, int maxRounds) {
    bool gameEnd = false;
    int roundsPlayed = 0;
    // Calculate total property count for territory victory condition
    int totalProperties = 0;
    if (board) {
        for (auto& tile : board->getTileList()) {
            if (std::dynamic_pointer_cast<PropertyTile>(tile)) {
                totalProperties++;
            }
        }
    }
    while (!gameEnd) {
        roundsPlayed++;
        for (auto& player : players) {
            if (player->isBankrupt()) {
                continue;
            }
            if (player->isInHospital()) {
                std::cout << player->getDisplayName() << " ���b��|��i�A���L���^�X ("
                    << player->getHospitalRoundLeft() << " �^�X�Ѿl)" << std::endl;
                player->updateHospitalStatus();
                continue;
            }
            Board::clearScreen();
            board->drawBoard();
            std::cout << "���� " << player->getDisplayName() << " ���^�X�C" << std::endl;
            if (!player->getCards().empty()) {
                std::cout << "�O�_�ϥιD��d�H(y/n): ";
                char useCard;
                std::cin >> useCard;
                if (useCard == 'y' || useCard == 'Y') {
                    player->displayCards(players);
                    std::cout << "��J�n�ϥΪ��d���Ǹ�: ";
                    int cardIndex;
                    std::cin >> cardIndex;
                    player->useCard(cardIndex - 1, players);
                }
            }
            int steps = player->rollDice();
            std::cout << player->getName() << " �Y�X�F " << steps << " �I�C" << std::endl;
            int oldPos = player->getPosition();
            int newPos = (oldPos + steps) % board->getSize();
            if (oldPos + steps >= board->getSize()) {
                // Passed start
                auto startTile = board->getTile(0);
                if (startTile) {
                    if (auto st = std::dynamic_pointer_cast<StartTile>(startTile)) {
                        st->passBy(player);
                    }
                    else {
                        player->addMoney(config.getPassingStartBonus());
                        std::cout << player->getName() << " �g�L�_�I�A��o $"
                            << config.getPassingStartBonus() << std::endl;
                    }
                }
            }
            player->setPosition(newPos);
            std::shared_ptr<Tile> tile = board->getTile(newPos);
            TileAction action = tile->landOn(player);
            if (action == TileAction::PURCHASE_PROPERTY) {
                auto prop = std::dynamic_pointer_cast<PropertyTile>(tile);
                if (prop) {
                    if (auto bot = std::dynamic_pointer_cast<BotPlayer>(player)) {
                        bot->purchaseProperty(prop);
                    }
                    else {
                        std::cout << "�O�_�ʶR " << prop->getName() << "? (y/n): ";
                        char buy;
                        std::cin >> buy;
                        if (buy == 'y' || buy == 'Y') {
                            prop->purchase(player);
                        }
                    }
                }
            }
            else if (action == TileAction::OWN) {
                auto prop = std::dynamic_pointer_cast<PropertyTile>(tile);
                if (prop && prop->getPropertyOwner() == player && prop->canUpgrade()) {
                    if (auto bot = std::dynamic_pointer_cast<BotPlayer>(player)) {
                        bot->upgradeProperty(prop);
                    }
                    else {
                        std::cout << "�O�_�ɯŸӦa���H(y/n): ";
                        char upr;
                        std::cin >> upr;
                        if (upr == 'y' || upr == 'Y') {
                            prop->upgrade(player);
                        }
                    }
                }
            }
            else if (action == TileAction::STORE) {
                auto store = std::dynamic_pointer_cast<StoreTile>(tile);
                if (store) {
                    if (auto bot = std::dynamic_pointer_cast<BotPlayer>(player)) {
                        // Bot buys first affordable card
                        auto stock = store->getAvailableCards();
                        for (size_t i = 0; i < stock.size(); ++i) {
                            if (player->getMoney() >= stock[i]->getPrice()) {
                                store->purchaseCard(i, player);
                                break;
                            }
                        }
                    }
                    else {
                        std::cout << "�n�ʶR�d���ܡH(��J�d���s���A0���L): ";
                        int choice;
                        std::cin >> choice;
                        if (choice > 0) {
                            store->purchaseCard(choice - 1, player);
                        }
                    }
                }
            }
            // Check win conditions
            bool win = false;
            std::shared_ptr<Player> winner = nullptr;
            if (victoryCondition == 1) {
                if (player->getMoney() >= config.getWinMoney()) {
                    win = true;
                    winner = player;
                }
            }
            else if (victoryCondition == 2) {
                int ownedCount = player->getProperties().size();
                if (ownedCount > totalProperties / 2) {
                    win = true;
                    winner = player;
                }
            }
            // Check elimination
            int aliveCount = 0;
            for (auto& p : players) {
                if (!p->isBankrupt()) {
                    aliveCount++;
                    winner = p;
                }
            }
            if (aliveCount <= 1 && winner) {
                win = true;
            }
            if (win && winner) {
                Board::clearScreen();
                board->drawBoard();
                std::cout << "���a " << winner->getName() << " �w�F���ӧQ����I"
                    << std::endl;
                gameEnd = true;
                break;
            }
        } // end for players
        if (gameEnd) {
            break;
        }
        if (victoryCondition == 3 && roundsPlayed >= maxRounds && maxRounds > 0) {
            // Points mode end
            Board::clearScreen();
            board->drawBoard();
            std::shared_ptr<Player> topPlayer = nullptr;
            long long topScore = LLONG_MIN;
            for (auto& p : players) {
                if (p->isBankrupt()) continue;
                long long score = p->getMoney();
                for (auto& prop : p->getProperties()) {
                    score += prop->getSellingPrice();
                }
                if (!topPlayer || score > topScore) {
                    topScore = score;
                    topPlayer = p;
                }
            }
            if (topPlayer) {
                std::cout << "���a " << topPlayer->getName()
                    << " �b�n���ɤ����o�̰����A��ӡI" << std::endl;
            }
            else {
                std::cout << "�C�������G�Ҧ����a�ү}���C" << std::endl;
            }
            gameEnd = true;
        }
    } // end while
}

void Game::changeState(State newState) {
    currentState = newState;
}

void Game::addPlayers(const std::vector<std::shared_ptr<Player>>& pls) {
    players = pls;
}