/**
 * @file HospitalTile.cpp
 * @brief HospitalTile ���O����@�ɮסC
 */

#include "HospitalTile.hpp"
#include "Game/Player.hpp"
#include <iostream>

using namespace std;

HospitalTile::HospitalTile(const size_t id, const std::string& name, int recoveryTime)
    : Tile(id, name), defaultRecoveryTime(recoveryTime) {
}

HospitalTile::~HospitalTile() {
}

TileAction HospitalTile::landOn(shared_ptr<Player> player) {
    // If a barrier is blocking this tile, do nothing special
    if (blocked) {
        return TileAction::NONE;
    }
    // If player is already admitted (e.g., due to being sent to hospital)
    if (player->isInHospital()) {
        return TileAction::HOSPITAL;
    }
    // Just visiting the hospital has no effect
    return TileAction::NONE;
}

void HospitalTile::admitPatient(shared_ptr<Player> player) {
    // Send the player to hospital for the default number of turns
    player->sendToHospital(defaultRecoveryTime);
}

void HospitalTile::dischargePatient(shared_ptr<Player> player) {
    // Remove the player from the hospital (they can resume playing)
    player->recoverFromHospital();
}

bool HospitalTile::isPatient(shared_ptr<Player> player) const {
    // Determine if the player is in hospital based on their state
    return player->isInHospital();
}

int HospitalTile::getRemainingRecoveryTurns(shared_ptr<Player> player) const {
    // We rely on Player's state (if accessible) for this information
    return player->isInHospital() ? 1 : 0; // (Placeholder: returns 1 if in hospital)
}

void HospitalTile::decrementRecoveryTurns(shared_ptr<Player> player) {
    if (player->isInHospital()) {
        player->updateHospitalStatus();
    }
}

void HospitalTile::setDefaultRecoveryTime(int turns) {
    defaultRecoveryTime = turns;
}

int HospitalTile::getDefaultRecoveryTime() const {
    return defaultRecoveryTime;
}